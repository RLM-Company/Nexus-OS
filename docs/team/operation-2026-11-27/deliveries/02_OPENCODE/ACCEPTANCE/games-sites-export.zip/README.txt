Kosmora Games+Sites export; source of truth is project.json and site.project.json.
